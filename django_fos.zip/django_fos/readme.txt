For Admin Account:
    Username: admin
    Password: admin123
    or, you can create one by creating new super user using terminale cmd: python manage.py createsuperuser

**Developed By Farid El-Aouadi**

********************************
Originally Developed By: Farid El-Aouadi
Original Version was Posted @: codeastro.com [https://codeastro.com/food-ordering-system-in-python-django-with-source-code/]

****************************************
Customized & Modified By: oretnom23
Customized & Modified Version was published @ sourcecodester.com [https://sourcecodester.com/django-framework-simple-food-ordering-system-project]
